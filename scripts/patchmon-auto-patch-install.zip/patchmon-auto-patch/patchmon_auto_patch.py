#!/usr/bin/env python3
"""
PatchMon automatic patching.

- Authenticates through POST /api/v1/auth/login.
- Uses the returned token as Cookie: token=<token>.
- Sends a persistent X-Device-ID and a fresh X-Request-ID.
- Discovers hosts and patch runs through paginated API calls.
- Skips stale/inactive hosts, hosts without pending updates, and hosts with
  non-terminal patch runs.
- Triggers patch_all; Windows receives both OS and app update scopes.
- Never reboots a host.
"""
from __future__ import annotations

import argparse
import fcntl
import json
import logging
import os
import sys
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

ENV_FILE = Path(os.environ.get("PATCHMON_ENV_FILE", "/etc/patchmon-auto-patch.env"))
LOCK_FILE = Path(os.environ.get("PATCHMON_LOCK_FILE", "/run/lock/patchmon-auto-patch.lock"))

# Statuses known to be terminal from observed PatchMon responses. Any unknown
# status is treated as active (fail closed) to avoid duplicate patch jobs.
TERMINAL_RUN_STATUSES = {"completed", "failed", "cancelled", "canceled", "skipped"}

def load_env_file(path: Path) -> None:
    if not path.exists():
        raise RuntimeError(f"Configuration file not found: {path}")
    for raw in path.read_text().splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        if key and key not in os.environ:
            os.environ[key] = value

def required(name: str) -> str:
    value = os.environ.get(name, "").strip()
    if not value or value.startswith("CHANGE_ME"):
        raise RuntimeError(f"Set {name} in {ENV_FILE}")
    return value

def setup_logging(log_file: str) -> None:
    Path(log_file).parent.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(message)s",
        handlers=[
            logging.FileHandler(log_file),
            logging.StreamHandler(sys.stdout),
        ],
    )

class PatchMon:
    def __init__(self, base_url: str, username: str, password: str,
                 device_id: str, timeout: int = 30):
        self.base_url = base_url.rstrip("/")
        self.username = username
        self.password = password
        self.device_id = device_id
        self.timeout = timeout
        self.token: str | None = None

    def request(self, method: str, path: str, payload: dict | None = None) -> Any:
        url = self.base_url + path
        headers = {
            "Accept": "application/json",
            "X-Device-ID": self.device_id,
            "X-Request-ID": str(uuid.uuid4()),
            "User-Agent": "patchmon-auto-patch/1.0",
        }
        data = None
        if payload is not None:
            data = json.dumps(payload).encode()
            headers["Content-Type"] = "application/json"
        if self.token:
            # Browser DevTools showed Cookie: token=... and no Authorization header.
            headers["Cookie"] = f"token={self.token}"
        req = Request(url, data=data, headers=headers, method=method)
        try:
            with urlopen(req, timeout=self.timeout) as response:
                raw = response.read()
                if not raw:
                    return {}
                try:
                    return json.loads(raw.decode("utf-8"))
                except json.JSONDecodeError as exc:
                    raise RuntimeError(f"Non-JSON response from {path}") from exc
        except HTTPError as exc:
            body = exc.read().decode("utf-8", errors="replace")[:1000]
            # Do not include request headers or credentials in logs/errors.
            raise RuntimeError(f"{method} {path} returned HTTP {exc.code}: {body}") from exc
        except URLError as exc:
            raise RuntimeError(f"Could not reach PatchMon at {url}: {exc.reason}") from exc

    def login(self) -> None:
        result = self.request("POST", "/api/v1/auth/login", {
            "username": self.username,
            "password": self.password,
        })
        token = result.get("token") if isinstance(result, dict) else None
        if not token:
            raise RuntimeError("Login response did not contain a token; refusing to continue")
        self.token = str(token)
        logging.info("Login successful; token will be sent as the token cookie")

    def paginated_items(self, path: str, page_size: int = 100) -> list[dict]:
        items: list[dict] = []
        offset = 0
        while True:
            query = urlencode({"limit": page_size, "offset": offset})
            result = self.request("GET", f"{path}?{query}")
            if not isinstance(result, dict) or not isinstance(result.get("items"), list):
                raise RuntimeError(f"Unexpected paginated response from {path}; refusing to proceed")
            page = result["items"]
            items.extend(x for x in page if isinstance(x, dict))
            total = result.get("total")
            if total is None:
                if len(page) < page_size:
                    break
                offset += len(page)
            else:
                total = int(total)
                if len(items) >= total or not page:
                    break
                offset += len(page)
        return items

    def hosts(self) -> list[dict]:
        # Host inventory response uses {"items": [...], "total": ..., ...}.
        return self.paginated_items("/api/v1/dashboard/hosts")

    def runs(self, page_size: int = 100) -> list[dict]:
        # The user's captured patch-run response uses {"runs": [...],
        # "pagination": {"total": ..., "pages": ..., ...}} rather than items.
        records: list[dict] = []
        offset = 0
        while True:
            query = urlencode({"limit": page_size, "offset": offset})
            result = self.request("GET", f"/api/v1/patching/runs?{query}")
            if not isinstance(result, dict) or not isinstance(result.get("runs"), list):
                raise RuntimeError("Unexpected patch-run response; refusing to proceed")
            page = result["runs"]
            records.extend(x for x in page if isinstance(x, dict))
            pagination = result.get("pagination") or {}
            total = pagination.get("total")
            if total is None:
                if len(page) < page_size:
                    break
                offset += len(page)
            else:
                total = int(total)
                if len(records) >= total or not page:
                    break
                offset += len(page)
        return records

    def trigger(self, host: dict) -> Any:
        body = {
            "host_id": host["id"],
            "patch_type": "patch_all",
        }
        os_type = str(host.get("os_type", "")).lower()
        if "windows" in os_type:
            body["windows_scope"] = {"updates": True, "apps": True}
        return self.request("POST", "/api/v1/patching/trigger", body)

def host_label(host: dict) -> str:
    return str(host.get("friendly_name") or host.get("hostname") or host.get("id") or "unknown")

def host_is_eligible(host: dict) -> tuple[bool, str]:
    if not host.get("id"):
        return False, "missing host ID"
    if host.get("effectiveStatus") != "active":
        return False, f"effectiveStatus={host.get('effectiveStatus')!r}"
    if host.get("isStale") is not False:
        return False, f"isStale={host.get('isStale')!r}"
    if host.get("reportingState") not in (None, "reporting"):
        return False, f"reportingState={host.get('reportingState')!r}"
    count = host.get("updatesCount")
    state = host.get("updateState")
    try:
        count_pending = int(count) > 0
    except (TypeError, ValueError):
        count_pending = False
    state_pending = state == "updates_pending"
    if not (count_pending or state_pending):
        return False, f"no pending updates (updatesCount={count!r}, updateState={state!r})"
    return True, "eligible"

def active_run_for_host(host_id: str, runs: list[dict]) -> dict | None:
    for run in runs:
        if str(run.get("host_id", "")) != str(host_id):
            continue
        status = str(run.get("status", "")).strip().lower()
        if status not in TERMINAL_RUN_STATUSES:
            return run
    return None

def run_main() -> int:
    parser = argparse.ArgumentParser(description="Patch eligible PatchMon hosts with patch_all.")
    parser.add_argument("--dry-run", action="store_true", help="List eligible hosts without patching.")
    parser.add_argument("--page-size", type=int, default=100)
    args = parser.parse_args()

    load_env_file(ENV_FILE)
    base_url = required("PATCHMON_URL")
    username = required("PATCHMON_USERNAME")
    password = required("PATCHMON_PASSWORD")
    device_id = required("PATCHMON_DEVICE_ID")
    log_file = os.environ.get("PATCHMON_LOG_FILE", "/var/log/patchmon-auto-patch/patchmon-auto-patch.log")
    setup_logging(log_file)

    LOCK_FILE.parent.mkdir(parents=True, exist_ok=True)
    lock_handle = LOCK_FILE.open("w")
    try:
        fcntl.flock(lock_handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        logging.warning("Another automation instance is running; exiting.")
        return 0

    client = PatchMon(base_url, username, password, device_id)
    try:
        client.login()

        # Both API reads must succeed and parse completely before any trigger.
        hosts = client.paginated_items("/api/v1/dashboard/hosts", args.page_size)
        runs = client.runs(args.page_size)
        logging.info("Discovered %d hosts and %d patch-run records.", len(hosts), len(runs))

        selected: list[dict] = []
        for host in hosts:
            eligible, reason = host_is_eligible(host)
            label = host_label(host)
            if not eligible:
                logging.info("SKIP %s (%s): %s", label, host.get("id"), reason)
                continue
            active = active_run_for_host(str(host["id"]), runs)
            if active:
                logging.info(
                    "SKIP %s (%s): existing run status=%s run_id=%s",
                    label, host["id"], active.get("status"), active.get("id", "unknown")
                )
                continue
            selected.append(host)

        logging.info("%d host(s) eligible for patch_all.", len(selected))
        if args.dry_run:
            for host in selected:
                logging.info("DRY RUN: would patch %s (%s), OS=%s",
                             host_label(host), host["id"], host.get("os_type"))
            return 0

        failures = 0
        for host in selected:
            label = host_label(host)
            try:
                result = client.trigger(host)
                logging.info("TRIGGER ACCEPTED %s (%s): %s",
                             label, host["id"],
                             json.dumps(result, separators=(",", ":"))[:1500])
            except Exception as exc:
                failures += 1
                logging.error("TRIGGER FAILED %s (%s): %s", label, host["id"], exc)

        # Re-read runs to capture any immediately-created job statuses.
        try:
            latest_runs = client.runs(args.page_size)
            for host in selected:
                run = active_run_for_host(str(host["id"]), latest_runs)
                if run:
                    logging.info("RUN STATUS %s (%s): %s",
                                 host_label(host), host["id"], run.get("status"))
        except Exception as exc:
            logging.error("Could not refresh run status after triggers: %s", exc)

        # Reboot status is reported by the host inventory; this script never reboots.
        try:
            refreshed_hosts = {str(h.get("id")): h for h in client.hosts()}
            for host in selected:
                refreshed = refreshed_hosts.get(str(host["id"]), {})
                if refreshed.get("needs_reboot") is True:
                    logging.warning("REBOOT REQUIRED %s (%s): %s; NOT rebooting.",
                                    host_label(host), host["id"],
                                    refreshed.get("reboot_reason") or "reason not supplied")
        except Exception as exc:
            logging.warning("Could not refresh reboot indicators: %s", exc)

        return 1 if failures else 0
    except Exception as exc:
        logging.exception("Automation aborted safely: %s", exc)
        return 2

if __name__ == "__main__":
    sys.exit(run_main())
